<?php

include_once 'lib/qode-instagram-api.php';
include_once 'widgets/load.php';