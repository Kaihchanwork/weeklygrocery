<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_portfolio-list/helper-functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_portfolio-list/portfolio-list.php';
