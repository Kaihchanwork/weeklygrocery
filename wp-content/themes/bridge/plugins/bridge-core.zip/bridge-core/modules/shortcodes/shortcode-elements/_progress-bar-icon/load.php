<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_progress-bar-icon/progress-bar-icon.php';
