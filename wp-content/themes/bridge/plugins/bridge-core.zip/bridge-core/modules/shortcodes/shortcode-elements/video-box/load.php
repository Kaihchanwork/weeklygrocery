<?php

require_once BRIDGE_CORE_SHORTCODES_PATH.'/video-box/functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/video-box/video-box.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/video-box/options-map/map.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/video-box/custom-styles/custom-styles.php';