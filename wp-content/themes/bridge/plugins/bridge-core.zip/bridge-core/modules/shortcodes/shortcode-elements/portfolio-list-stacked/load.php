<?php

include_once BRIDGE_CORE_SHORTCODES_PATH.'/portfolio-list-stacked/portfolio-list-stacked.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/portfolio-list-stacked/helper-functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/portfolio-list-stacked/custom-styles/custom-styles.php';