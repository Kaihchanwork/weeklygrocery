<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_animation-holder/animation-holder.php';
