<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_social-share-list/social-share-list.php';
