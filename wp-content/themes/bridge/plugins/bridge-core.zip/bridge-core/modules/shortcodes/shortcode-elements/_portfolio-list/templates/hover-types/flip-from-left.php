<div class="portfolio_title_holder">
    <?php echo bridge_core_get_shortcode_template_part( 'templates/parts/title', '_portfolio-list', $type, $params ); ?>
</div>