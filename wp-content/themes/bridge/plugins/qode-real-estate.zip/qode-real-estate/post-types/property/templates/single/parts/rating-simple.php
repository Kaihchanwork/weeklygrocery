<?php
if(qodef_re_qodef_core_plugin_installed()) {
    echo qodef_core_list_review_details('stars-simple');
}