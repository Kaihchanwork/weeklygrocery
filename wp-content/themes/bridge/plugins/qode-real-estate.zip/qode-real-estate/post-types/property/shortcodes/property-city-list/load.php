<?php
require_once 'property-city-list.php';
require_once 'helper-functions.php';