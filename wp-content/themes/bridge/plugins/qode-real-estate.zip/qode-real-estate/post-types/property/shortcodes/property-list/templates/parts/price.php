<?php
$price = qodef_re_get_real_estate_item_price();
?>
<span class="qodef-property-price">
    <?php echo qodef_re_get_real_estate_price_html($price); ?>
</span>
