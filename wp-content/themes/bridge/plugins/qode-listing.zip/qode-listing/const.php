<?php
define('QODE_LISTING_VERSION', '3.0.7');
define('QODE_LISTING_ABS_PATH', dirname(__FILE__));
define('QODE_LISTING_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('QODE_LISTING_URL_PATH', plugin_dir_url( __FILE__ ));
define('QODE_LISTING_ASSETS_PATH', QODE_LISTING_ABS_PATH.'/assets');
define('QODE_LISTING_ASSETS_URL_PATH', QODE_LISTING_URL_PATH.'assets');
define('QODE_LISTING_CPT_PATH', QODE_LISTING_ABS_PATH.'/post-types');
define('QODE_LISTING_CPT_URL_PATH', QODE_LISTING_URL_PATH.'post-types');
define('QODE_LISTING_SHORTCODES_PATH', QODE_LISTING_ABS_PATH.'/modules/shortcodes');
define('QODE_LISTING_SHORTCODES_URL_PATH', QODE_LISTING_URL_PATH.'shortcodes');
