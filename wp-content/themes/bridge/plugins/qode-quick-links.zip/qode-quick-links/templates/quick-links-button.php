<div class="qode-quick-links-button">
	<?php if(isset($button_logo)) { ?>
		<img src="<?php echo esc_url($button_logo)?>" alt="" />
	<?php } ?>
	<span class="qode-quick-links-count"><?php echo esc_attr($count)?></span>
</div>