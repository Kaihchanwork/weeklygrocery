<div class="qode-comment-input-title">
	<label><?php esc_html_e( 'Title of your Review', 'qode-lms' ) ?></label>
	<input id="title" name="qode_comment_title" class="qode-input-field" type="text" placeholder=""/>
</div>